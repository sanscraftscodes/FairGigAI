
# FairGig AI — Final ML Model Handoff

## Project

FairGig AI is a multi-agent AI system for fair and explainable gig-task
allocation.

The ML component predicts worker-task success probability and the fairness
layer uses the prediction together with efficiency and workload/opportunity
signals to allocate tasks.

## Final ML architecture

1. Task Analysis Agent
2. Worker Profile / Suitability Agent
3. ML Success Prediction
4. Fairness Evaluation
5. WAFR Allocation
6. Explainability Agent

## Final trained ML setup

Workers: 1000
Tasks: 3000
Candidate worker-task pairs: 300000

The experiment uses task-grouped train/validation/test splitting so that
the same task does not appear across multiple splits.

## Models

- Balanced Logistic Regression
- HistGradientBoosting
- XGBoost
- LightGBM
- CatBoost
- Validation-selected ensemble

## Important evaluation note

The reported overall held-out ensemble metrics are approximately:

ROC-AUC: 0.9561
PR-AUC: 0.2431
Brier Score: 0.0187

Overall positive prevalence is approximately 2.27%, so the random PR-AUC
baseline is approximately 0.0227.

Therefore PR-AUC should be interpreted relative to prevalence rather than
as an isolated percentage.

IMPORTANT:
The actual allocation system first filters workers using hard eligibility.
Therefore, an eligible-only test evaluation should be added before making
claims about how well the model ranks success among eligible workers.

## Fairness allocation

WAFR combines:

- predicted success
- operational efficiency
- opportunity credit
- workload pressure

with:

0.70 * predicted_success
+ 0.30 * efficiency
+ lambda * opportunity_credit
- lambda * workload_pressure

## Explainability

The package contains available feature-importance and SHAP artifacts from
the final notebook.

Vehicle-related features may have high importance because vehicle
compatibility is strongly related to eligibility. This should not automatically
be interpreted as proof that vehicle type is the dominant predictor of
success among already-eligible workers.

## For application development

Do NOT retrain the model automatically.

First load:

1. preprocessing object
2. trained model(s)
3. ensemble configuration
4. threshold
5. feature configuration

Then implement an inference pipeline that accepts:

Task
+
Worker profile
+
Historical worker features

and returns:

worker_id
predicted_success_probability
eligibility
suitability
fairness signals
final allocation score
explanation

## Security / engineering

Never expose model files or internal training data directly through the
frontend.

The model should be loaded by a backend API.

Recommended separation:

Frontend
    ->
FastAPI backend
    ->
Task Analysis / Worker Processing
    ->
ML Prediction
    ->
Fairness / WAFR
    ->
Allocation
    ->
Explainability
    ->
Response

